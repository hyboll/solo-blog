title: CentOS 7.x 安装 JDK 详细步骤
date: '2019-09-20 10:47:43'
updated: '2019-10-28 16:35:55'
tags: [Linux]
permalink: /articles/2019/09/20/1568947662989.html
---
![](https://img.hacpai.com/bing/20190222.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

> ## 目录

&nbsp;&nbsp;&nbsp;&nbsp;一、安装准备
&nbsp;&nbsp;&nbsp;&nbsp;二、yum 安装
&nbsp;&nbsp;&nbsp;&nbsp;三、rpm 安装
&nbsp;&nbsp;&nbsp;&nbsp;四、tar.gz 安装

---
> ## 系统

查看系统版本命令

```
cat /etc/redhat-release
```

![cat.png](https://img.hacpai.com/file/2019/09/cat-60bb8950.png)

本文将介绍常用的三种安装方式：yum、rpm、tar.gz，下面开始安装步骤。

---
> ## 安装准备

安装之前先用命令查看一下系统有没有自带 JDK 或安装了旧版 JDK

```
rpm -qa | grep java
```
```
rpm -qa | grep jdk
```
```
rpm -qa | grep gcj
```

![rpmqa.png](https://img.hacpai.com/file/2019/09/rpmqa-361f9e18.png)

如果没有就跳过该步骤，如果有就用以下命令删除文件

> 批量删除所有带 java 的文件

```
rpm -qa | grep java | xargs  rpm -e --nodeps 
```

> 删除单个文件或多个文件，文件名之间用空格隔开，noarch 文件可以不删除

```
rpm -e --nodeps java-1.8.0-openjdk-headless-debug-1.8.0.222.b10-1.el7_7.x86_64
```

---
> ## yum 安装

通过以下命令可以查看 Java 版本列表

```
yum list java
```

我这里安装的是 1.8 版本的 OpenJDK

```
yum install -y java-1.8.0-openjdk*
```

经过漫长的等待（网速不好）后，终于安装完成，使用命令查看是否安装成功

```
java -version
```

![version.png](https://img.hacpai.com/file/2019/09/version-834220e6.png)

**总结：** 安装简单方便，无需手动下载任何文件、配置环境变量，真正的一键安装。

---

> ## rpm 安装

到[官网](https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)下载 rpm 格式的 JDK 并上传到 Linux 中，这里以 jdk-8u181-linux-x64.rpm 为例进行安装说明。

> rpm 安装命令
```
rpm -ivh jdk-8u181-linux-x64.rpm
```
![rpmivh.png](https://img.hacpai.com/file/2019/09/rpmivh-0da60ffd.png)

至此，安装完成，使用命令查看是否安装成功

```
java -version
```
![version.png](https://img.hacpai.com/file/2019/09/version-8d0e48b3.png)

**总结：** 安装总体来说还是比较简单的，比 yum 安装多了下载 JDK rpm安装包的步骤，同样无需配置环境变量。

---

> ## tar.gz 安装

到[官网](https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)下载 tar.gz 后缀的 JDK 并上传到 Linux 中，这里以 jdk-8u231-linux-x64.tar.gz 为例进行安装说明。

>  进入 JDK 文件存放目录

![software.png](https://img.hacpai.com/file/2019/10/software-8559c931.png)  

目录可以根据自己需求创建，也可以存放在根目录下。

> 解压文件

```
tar -zxvf jdk-8u231-linux-x64.tar.gz
```

![tar.png](https://img.hacpai.com/file/2019/10/tar-535f31c1.png)

解压后的文件，接下来是配置环境变量，配置环境变量之前可以将解压出来的文件移至自己需要的位置。

> 配置环境变量

```
vim /etc/profile
```

没有 **vim** 命令的同学请使用 **vi** 命令

```
vi /etc/profile
```

![image.png](https://img.hacpai.com/file/2019/10/image-0bcc6dfd.png)

进入文本界面后按 **i** 进入编辑模式，光标移到尾部，追加以下文本

```
#java environment
export JAVA_HOME=/usr/local/software/jdk1.8.0_231
export CLASSPATH=.:${JAVA_HOME}/jre/lib/rt.jar:${JAVA_HOME}/lib/dt.jar:${JAVA_HOME}/lib/tools.jar
export PATH=$PATH:${JAVA_HOME}/bin
```

![image.png](https://img.hacpai.com/file/2019/10/image-9431a143.png)


按esc退出编辑模式，然后再输入 **:wq**  保存并退出文本编辑。

> 刷新配置文件

```
source /etc/profile
```  

至此，安装完成，使用命令查看是否安装成功

```
java -version
```

![image.png](https://img.hacpai.com/file/2019/10/image-5fcab67b.png)

同时，还可以使用 `java` 与 `javac` 命令查看环境变量配置是否正确。

**总结：** 安装相对于 yum 和 rpm 安装复杂了些许，而且还得手动配置环境变量，这一步容易出错，建议使 yum 和 rpm 方式安装。
