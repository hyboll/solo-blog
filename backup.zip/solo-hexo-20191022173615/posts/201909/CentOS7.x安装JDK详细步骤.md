title: CentOS 7.x 安装 JDK 详细步骤
date: '2019-09-20 10:47:43'
updated: '2019-09-20 18:02:55'
tags: [Linux]
permalink: /articles/2019/09/20/1568947662989.html
---
> ## 目录

&nbsp;&nbsp;&nbsp;&nbsp;一、安装准备
&nbsp;&nbsp;&nbsp;&nbsp;二、yum 安装
&nbsp;&nbsp;&nbsp;&nbsp;三、rpm 安装
&nbsp;&nbsp;&nbsp;&nbsp;四、tar.gz 安装
&nbsp;&nbsp;&nbsp;&nbsp;五、文中命令详解

---
> ## 系统

查看系统版本命令

```
cat /etc/redhat-release
```

![cat.png](https://img.hacpai.com/file/2019/09/cat-60bb8950.png)

本文将介绍常用的三种安装方式：yum、rpm、tar.gz，下面开始安装步骤。

---
> ## 安装准备

安装之前先用命令查看一下系统有没有自带 JDK 或安装了旧版 JDK

```
rpm -qa | grep java
```
```
rpm -qa | grep jdk
```
```
rpm -qa | grep gcj
```

![rpmqa.png](https://img.hacpai.com/file/2019/09/rpmqa-361f9e18.png)

如果没有就跳过该步骤，如果有就用以下命令删除文件

> 批量删除所有带 java 的文件

```
rpm -qa | grep java | xargs  rpm -e --nodeps 
```

> 删除单个文件或多个文件，文件名之间用空格隔开，noarch 文件可以不删除

```
rpm -e --nodeps java-1.8.0-openjdk-headless-debug-1.8.0.222.b10-1.el7_7.x86_64
```

---
> ## yum 安装

通过以下命令可以查看 Java 版本列表

```
yum list java
```

我这里安装的是 1.8 版本的 OpenJDK

```
yum install -y java-1.8.0-openjdk*
```

经过漫长的等待后（网速不好）终于安装完成，使用命令查看是否安装成功

```
java -version
```

![version.png](https://img.hacpai.com/file/2019/09/version-834220e6.png)

**总结：** 安装简单方便，无需手动下载任何文件、配置环境变量，真正的一键安装。

---

> ## rpm 安装

到[官网](https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)下载 rpm 格式的 JDK 并上传到 Linux 中，这里以 jdk-8u181-linux-x64.rpm 为例进行安装说明。

> rpm 安装命令
```
rpm -ivh jdk-8u181-linux-x64.rpm
```
![rpmivh.png](https://img.hacpai.com/file/2019/09/rpmivh-0da60ffd.png)

至此，安装完成，使用命令查看是否安装成功

```
java -version
```
![version.png](https://img.hacpai.com/file/2019/09/version-8d0e48b3.png)


